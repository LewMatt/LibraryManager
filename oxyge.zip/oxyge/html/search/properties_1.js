var searchData=
[
  ['databasename_228',['DatabaseName',['../class_library___manager_1_1_d_b_connection.html#ac0bac84fc161c5cdee570eda3bf3bd64',1,'Library_Manager::DBConnection']]]
];
