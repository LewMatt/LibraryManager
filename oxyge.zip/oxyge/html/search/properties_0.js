var searchData=
[
  ['connection_227',['Connection',['../class_library___manager_1_1_d_b_connection.html#a3b4ab302fbc6bdbce4a2313d1868eff2',1,'Library_Manager::DBConnection']]]
];
