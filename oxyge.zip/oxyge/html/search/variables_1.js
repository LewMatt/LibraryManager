var searchData=
[
  ['data_5fodd_202',['data_odd',['../class_library___manager_1_1_user_control_zamowiena_admin.html#a92bec28a37695514b422d83b125c4ee6',1,'Library_Manager::UserControlZamowienaAdmin']]],
  ['data_5fza_5fmies_203',['data_za_mies',['../class_library___manager_1_1_user_control_biblioteka.html#afe119d092e35cc577797c8a3fa350eb6',1,'Library_Manager::UserControlBiblioteka']]]
];
