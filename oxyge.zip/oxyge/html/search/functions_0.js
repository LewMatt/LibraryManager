var searchData=
[
  ['btnbiblioteka_5fclick_164',['btnBiblioteka_Click',['../class_library___manager_1_1_form_menu.html#a3c42d3244c13fe8602fe9c4709e08bee',1,'Library_Manager.FormMenu.btnBiblioteka_Click()'],['../class_library___manager_1_1_form_menu_admin.html#a845667f940e7f71466482cd83f7214f1',1,'Library_Manager.FormMenuAdmin.btnBiblioteka_Click()']]],
  ['btnksiazkiwypozyczone_5fclick_165',['btnKsiazkiWypozyczone_Click',['../class_library___manager_1_1_form_menu_admin.html#a92c21326defe75b6cc61857f9ef43beb',1,'Library_Manager::FormMenuAdmin']]],
  ['btnmojedane_5fclick_166',['btnMojeDane_Click',['../class_library___manager_1_1_form_menu.html#a567a19a563751cb7313871a2645d5dfa',1,'Library_Manager::FormMenu']]],
  ['btnmojeksiazki_5fclick_167',['btnMojeKsiazki_Click',['../class_library___manager_1_1_form_menu.html#a95793e8ad4b39c5a7e52c57d940c0d16',1,'Library_Manager::FormMenu']]],
  ['btnuzytkownicy_5fclick_168',['btnUzytkownicy_Click',['../class_library___manager_1_1_form_menu_admin.html#aa9b308df73e4fa70f3b390760aa2bd50',1,'Library_Manager::FormMenuAdmin']]],
  ['btnzamowienia_5fclick_169',['btnZamowienia_Click',['../class_library___manager_1_1_form_menu_admin.html#a2e61f58ea922f5fbd2e14ec7dd1fa18c',1,'Library_Manager::FormMenuAdmin']]],
  ['btnzamowksiazke_5fclick_170',['btnZamowKsiazke_Click',['../class_library___manager_1_1_form_menu.html#a337e3a612950d0e0538a1dbbe8a3138b',1,'Library_Manager::FormMenu']]]
];
