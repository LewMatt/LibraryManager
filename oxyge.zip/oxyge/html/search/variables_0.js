var searchData=
[
  ['btnmojeksiazki_201',['btnMojeKsiazki',['../class_library___manager_1_1_form_menu.html#a18b0e245dbb3baf0c718d2bfa7373955',1,'Library_Manager::FormMenu']]]
];
