var searchData=
[
  ['dbconnection_106',['DBConnection',['../class_library___manager_1_1_d_b_connection.html',1,'Library_Manager']]]
];
