var searchData=
[
  ['sendqueryretbooks_184',['sendQueryRetBooks',['../class_library___manager_1_1_form1.html#aca4c12dffb53b270c2980cc77fac3d46',1,'Library_Manager::Form1']]],
  ['sendqueryretbooksborrowed_185',['sendQueryRetBooksBorrowed',['../class_library___manager_1_1_form1.html#acb4cabe973ce5524704ea0cd6b06d741',1,'Library_Manager::Form1']]],
  ['sendqueryretbooksordered_186',['sendQueryRetBooksOrdered',['../class_library___manager_1_1_form1.html#a9c7f6bbfe55b5e10c9af16b8d954a97f',1,'Library_Manager::Form1']]],
  ['sendqueryretstring_187',['sendQueryRetString',['../class_library___manager_1_1_form1.html#a6374cdccce65424470280ce3759506ac',1,'Library_Manager::Form1']]],
  ['sendqueryretuserbooks_188',['sendQueryRetUserBooks',['../class_library___manager_1_1_form1.html#aeca74a3a0f81da3164ecc610211fcac0',1,'Library_Manager::Form1']]],
  ['sendqueryretusers_189',['sendQueryRetUsers',['../class_library___manager_1_1_form1.html#a288c9f28935848308ca2bbb3017c0680',1,'Library_Manager::Form1']]]
];
